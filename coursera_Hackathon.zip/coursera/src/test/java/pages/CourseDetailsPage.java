package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CourseDetailsPage {
    WebDriver driver;

    public CourseDetailsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // WebElements
    @FindBy(xpath = "//h3[text()='Introduction to Web Development']")
    WebElement course1Title;

    @FindBy(xpath = "//*[@id=\"searchResults\"]/div[1]/div/ul[1]/li[1]/div/div/div/div/div/div[2]/div[3]")
    WebElement course1Rating;

    @FindBy(xpath = "//h3[text()='Introduction to Front-End Development']")
    WebElement course2Title;

    @FindBy(xpath = "//*[@id=\"searchResults\"]/div[1]/div/ul[1]/li[2]/div/div/div/div/div/div[2]/div[3]")
    WebElement course2Rating;

    @FindBy(xpath = "//span[text()='Show 26 more']")
    WebElement showMoreLanguages;

    @FindBy(xpath = "//h4/div[text()='Language']//following::div[contains(@data-testid , 'language')]")
    List<WebElement> languageElements;

    @FindBy(xpath = "//span[@id='cds-react-aria-:Rhlbdj4tacqkqikta:-label-text']")
    WebElement beginnerLevel;

    @FindBy(xpath = "//div[@data-testid='productDifficultyLevel:Intermediate-false']")
    WebElement intermediateLevel;

    @FindBy(xpath = "//div[@data-testid='productDifficultyLevel:Advanced-false']")
    WebElement advancedLevel;

    @FindBy(xpath = "//div[@data-testid='productDifficultyLevel:Mixed-false']")
    WebElement mixedLevel;

    // Actions
    public void printCourseInfo() {
        String title1 = course1Title.getText();
        String rating1 = course1Rating.getText();
        System.out.println("Course 1 Title : " + title1 + " , Rating : " + rating1);

        String title2 = course2Title.getText();
        String rating2 = course2Rating.getText();
        System.out.println("Course 2 Title : " + title2 + " , Rating : " + rating2);
    }

    public void printLanguages() {
        showMoreLanguages.click();
        System.out.println("\n LANGUAGES :- \n");
        for (WebElement lang : languageElements) {
            System.out.println(lang.getText());
        }
    }

    public void printLevels() {
        System.out.println("\n LEVELS :- \n");
        System.out.println(beginnerLevel.getText());
        System.out.println(intermediateLevel.getText());
        System.out.println(advancedLevel.getText());
        System.out.println(mixedLevel.getText());
    }
}
