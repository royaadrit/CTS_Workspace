package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
    WebDriver driver;

    // Constructor
    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Page Elements
    @FindBy(id = "search-autocomplete-input")
    WebElement searchInput;

    @FindBy(className = "search-button")
    WebElement searchButton; // Although clicked via JS, still defined here

    // Page Action
    public void searchCourse(String courseName) {
        searchInput.sendKeys(courseName);

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", searchButton);
    }
}
