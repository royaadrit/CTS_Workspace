package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ContactFormPage {

    WebDriver driver;

    // Constructor
    public ContactFormPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Page Elements
    @FindBy(xpath = "//*[@id=\"rendered-content\"]/div/div/div[2]/footer/div[2]/div/div/div[5]/ul/li[10]/a")
    WebElement contactLink;

    @FindBy(xpath = "//span[text()='Contact us']")
    WebElement contactUsButton;

    @FindBy(id = "FirstName")
    WebElement firstName;

    @FindBy(id = "LastName")
    WebElement lastName;

    @FindBy(id = "Email")
    WebElement email;

    @FindBy(id = "Phone")
    WebElement phone;

    @FindBy(id = "rentalField9")
    WebElement rentalDropdown;

    @FindBy(id = "Title")
    WebElement title;

    @FindBy(id = "Company")
    WebElement company;

    @FindBy(id = "Employee_Range__c")
    WebElement employeeRangeDropdown;

    @FindBy(id = "What_the_lead_asked_for_on_the_website__c")
    WebElement leadRequestDropdown;

    @FindBy(id = "Country")
    WebElement countryDropdown;

    @FindBy(id = "State")
    WebElement stateDropdown;

    @FindBy(id = "Self_reported_employees_to_buy_for__c")
    WebElement reportedEmployeesDropdown;

    @FindBy(xpath = "//button[@class='mktoButton']")
    WebElement submitButton;

    // Page Actions
    public void fillForm() throws InterruptedException {
        contactLink.click();
        contactUsButton.click();

        firstName.sendKeys("Sumit");
        lastName.sendKeys("kumar");
        email.sendKeys("cbhcbcu@gmail.com");
        phone.sendKeys("7878654212");

        new Select(rentalDropdown).selectByIndex(1);
        title.sendKeys("QEA");
        company.sendKeys("CTS");
        new Select(employeeRangeDropdown).selectByIndex(1);
        new Select(leadRequestDropdown).selectByIndex(1);
        new Select(countryDropdown).selectByIndex(1);
        new Select(stateDropdown).selectByIndex(1);
        new Select(reportedEmployeesDropdown).selectByIndex(1);

        submitButton.click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
    }
}
