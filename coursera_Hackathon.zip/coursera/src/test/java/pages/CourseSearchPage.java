package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CourseSearchPage {

    WebDriver driver;

    // Constructor
    public CourseSearchPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Page Element
    @FindBy(id = "cds-react-aria-:Rhlbdj4tacqkqikta:")
    WebElement firstCourse;

    // Page Action
    public void clickFirstCourse() {
        firstCourse.click();
    }
}
