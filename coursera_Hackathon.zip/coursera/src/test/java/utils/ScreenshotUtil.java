package utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenshotUtil {
	
	public static void captureScreenshot(WebDriver driver, String filePath) {
		try {
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0, -500);");
			TakesScreenshot ts = (TakesScreenshot)driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			File dest = new File(filePath);
			FileUtils.copyFile(source, dest);
			System.out.println("Screenshot saved");
			
		}catch(IOException e) {
			System.out.println("Failed to capture screenshot : "+ e.getMessage());
		}
	}

}
