package tests;

import org.testng.annotations.Test;

import base.BaseTest;
import pages.HomePage;
import pages.CourseDetailsPage;
import pages.ContactFormPage;
import pages.CourseSearchPage;

import utils.ScreenshotUtil;

public class CoursesTest extends BaseTest{
	
	@Test
	public void testCoursesSearchAndForn() throws Exception{
		HomePage home = new HomePage(driver);
		CourseSearchPage search = new CourseSearchPage(driver);
		CourseDetailsPage details = new CourseDetailsPage(driver);
		ContactFormPage form = new ContactFormPage(driver);
		
		home.searchCourse("web development courses");
		search.clickFirstCourse();
		details.printCourseInfo();
		details.printLanguages();
		details.printLevels();
		form.fillForm();
		ScreenshotUtil.captureScreenshot(driver, "C:\\Users\\2408330\\eclipse-workspace\\coursera\\src\\test\\resources\\screenshot.png");
		
	}

}
