package Tests;

import org.testng.annotations.Test;

import base.BaseTest;
import pages.FilteredBenches;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;

public class FilteredBenchesTest extends BaseTest {
	@Test
	public void displayFilteredBenchesTest() {
		//FilteredBenches fb = new FilteredBenches(driver);
		String actualResult[] = fb.scrollToCountAndDsiplay().split(" ");
		System.out.println("Metal Benches : " + actualResult[0]);
		Assert.assertEquals(actualResult[0], "7");
	}

}
