package Tests;

import org.testng.annotations.Test;

import base.BaseTest;
import pages.SettesAndBenchesPage;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;

public class SetteesAndBenchesTest extends BaseTest {
		

	@Test(priority = 1)
	public void checkSettesCount() {
		System.out.println("Settes count : " + sb.displaySettesCount());
		String actualOutput = sb.displaySettesCount();
		Assert.assertEquals(actualOutput, "20 options");
	}
	
	@Test(priority = 2)
	public void checkBenchesCount() {
		System.out.println("Benches count : " + sb.displayBenchesCount());
		String actualOutput = sb.displayBenchesCount();
		Assert.assertEquals(actualOutput, "144 options");
	}
	
	@Test(priority = 3)
	public void checkReclinerCount() {
		System.out.println("Recliner count : " + sb.displayReclinerCount());
		String actualOutput = sb.displayReclinerCount();
		Assert.assertEquals(actualOutput, "24 options");
	}
	
	@Test(priority = 4)
	public void checkScrollToFilter() {
		sb.scrollToMaterialFilterAndClick();
	}
	
	@Test(priority = 5)
	public void materialFilterCheck() {
		sb.clickMetalBenchFilter();
	}
	
	@Test(priority = 6)
	public void clickApplyButtonCheck() {
		sb.clickApplyFilterButton();
	}
}
