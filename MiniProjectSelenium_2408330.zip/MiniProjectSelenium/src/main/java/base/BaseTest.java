package base;

import java.io.IOException;
import java.lang.reflect.Method;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;


import io.github.bonigarcia.wdm.WebDriverManager;
import pages.FilteredBenches;
import pages.HomePage;
import pages.SettesAndBenchesPage;
import utility.ConfigReader;
import utility.ExtentReportManager;
import utility.ScreenshotUtil;

public class BaseTest {
	protected static WebDriver driver;
	protected ExtentTest test;
	protected static SettesAndBenchesPage sb;
	protected static HomePage hp;
	protected static FilteredBenches fb;
	
	public static void initialize()
	{
		hp = new HomePage(driver); 
		sb = new SettesAndBenchesPage(driver);
		fb = new FilteredBenches(driver);	
	}
	
        
	@BeforeSuite
	public void startReport()
	{
		ExtentReportManager.getExtentReport();
		//initialize();
		
	}
	@BeforeTest
	public void setup() throws IOException, InterruptedException{
		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		
		ConfigReader.readConfig();
		driver.get(ConfigReader.getURL());
		//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		Thread.sleep(10000); 
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.elementFromPoint(0, 0).click();");
		initialize();
	}
	
	
	@BeforeMethod
	public void createTest(Method method)
	{
		test = ExtentReportManager.startTest(method.getName());
	}
	
	@AfterMethod
    public void tearDown(ITestResult result)
	{
		if (result.getStatus() == ITestResult.SUCCESS)
        {
            String screenshotPath = ScreenshotUtil.takeScreenshot(driver, result.getName());
            test.log(Status.PASS, result.getName() + " is passed");
            test.addScreenCaptureFromPath(screenshotPath);
        }
		
        if (ITestResult.FAILURE == result.getStatus())
        {
            String screenshotPath = ScreenshotUtil.takeScreenshot(driver, result.getName());
            test.log(Status.FAIL, result.getName() + " is failed");
            test.addScreenCaptureFromPath(screenshotPath);
        }
    }
        
	
	
	 @AfterSuite
    public void endReport()
	    {
	        ExtentReportManager.flushReport();
	        driver.quit();
	    }
 
 
}
