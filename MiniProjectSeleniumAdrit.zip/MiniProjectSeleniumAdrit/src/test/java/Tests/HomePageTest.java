package Tests;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import base.BaseTest;
import pages.HomePage;

import java.io.IOException;

public class HomePageTest extends BaseTest {
    @Test(priority = 1)
    public void checkPageTitle() {
        //HomePage hp = new HomePage(driver);
    	String title = hp.getPageTitle();
        System.out.println("Page Title: " + title);
        Assert.assertEquals(title, "Buy Settees & Benches Online with Upto 60% Off | Pepperfry");
    }
}
