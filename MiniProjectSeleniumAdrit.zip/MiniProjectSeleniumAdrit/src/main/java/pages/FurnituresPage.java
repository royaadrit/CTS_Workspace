package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FurnituresPage {
	private JavascriptExecutor js;
	public FurnituresPage(WebDriver driver) {
		this.js = (JavascriptExecutor) driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "/html/body/app-root/main/app-category/pf-clp/div/div[1]/div/div/pf-category-list/div/div[3]")
	WebElement showMoreCategoriesButton;
	
	@FindBy(xpath = "//*[@id=\"card-content\"]/h3/a") 
	WebElement settesAndBenches;
	public void clickSettesAndBenches() {
		settesAndBenches.click();
	}
	
	public void clickMoreCategories() {
        while (!showMoreCategoriesButton.isDisplayed()) {
            js.executeScript("window.scrollBy(0, 100);");
            try {
                Thread.sleep(500); // Adjust the sleep time as needed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        showMoreCategoriesButton.click();
    }
	
	public void scrollToCategoryAndClick() {
        while (!settesAndBenches.isDisplayed()) {
            js.executeScript("window.scrollBy(0, 100);");
            try {
                Thread.sleep(500); // Adjust the sleep time as needed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        settesAndBenches.click();
    }
	
	/*
	 * 		

public class HomePage {

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
    private WebDriver driver;
    private JavascriptExecutor js;

    @FindBy(id = "furnitureButtonId")
    private WebElement furnitureButton;

    @FindBy(id = "moreCategoriesButtonId")
    private WebElement moreCategoriesButton;

    @FindBy(id = "desiredCategoryId")
    private WebElement desiredCategory;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

    public void clickFurniture() {
        furnitureButton.click();
    }

    public void clickMoreCategories() {
        while (!moreCategoriesButton.isDisplayed()) {
            js.executeScript("window.scrollBy(0, 100);");
            try {
                Thread.sleep(500); // Adjust the sleep time as needed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        moreCategoriesButton.click();
    }

    public void scrollToCategoryAndClick() {
        while (!desiredCategory.isDisplayed()) {
            js.executeScript("window.scrollBy(0, 100);");
            try {
                Thread.sleep(500); // Adjust the sleep time as needed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        desiredCategory.click();
    }
}

    private WebDriver driver;
    private JavascriptExecutor js;

    @FindBy(id = "showAllCategoriesButtonId")
    private WebElement showAllCategoriesButton;

    @FindBy(id = "desiredCategoryId")
    private WebElement desiredCategory;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

    public void clickShowAllCategories() {
        showAllCategoriesButton.click();
    }

    public void scrollToCategoryAndClick() {
        while (!desiredCategory.isDisplayed()) {
            js.executeScript("window.scrollBy(0, 100);");
            try {
                Thread.sleep(500); // Adjust the sleep time as needed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        desiredCategory.click();
    }
}

	 * 
	 */
}

