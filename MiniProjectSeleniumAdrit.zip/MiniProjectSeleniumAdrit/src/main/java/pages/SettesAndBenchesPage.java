package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SettesAndBenchesPage {
	private JavascriptExecutor js;
	public SettesAndBenchesPage(WebDriver driver) {
		this.js = (JavascriptExecutor) driver;
		PageFactory.initElements(driver, this);
		driver.navigate().to("https://www.pepperfry.com/category/settees-and-benches.html?type=hover-furniture-setteesbenches");
	}
	
	@FindBy(xpath = "//h1//following::div[text()='20 options']")
	WebElement settesCount;
	public String displaySettesCount() {
		return settesCount.getText();
	}
	
	@FindBy(xpath = "//h1//following::div[text()='150 options']")
	WebElement benchesCount;
	public String displayBenchesCount() {
		return benchesCount.getText();
	}
	
	@FindBy(xpath = "//h1//following::div[text()='25 options']")
	WebElement reclinersCount;
	public String displayReclinerCount() {
		return reclinersCount.getText();
	}
	
	//@FindBy(xpath = "//*[@id=\"Material\"]/div/span")
	@FindBy(xpath = "//span[text()='Material']")
	WebElement materialFilter;	
	public void scrollToMaterialFilterAndClick() {
        
            js.executeScript("arguments[0].scrollIntoView({block: 'center'})", materialFilter);
            try {
                Thread.sleep(10000); // Adjust the sleep time as needed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
       materialFilter.click();
    }
	
	//@FindBy(xpath = "/html/body/app-root/main/app-category/pf-clip/div/div[1]/div[3]/pf-clip-filter/div[2]/pf-clip-filter-drawer/div/pf-drawer/div/div[2]/div/div[1]/div[2]/pf-accordion/div/div/accordion/div/accordion-group[3]/div/div[2]/div/div/div/div[4]/span[1]/pf-checkbox/div/div/label")
	@FindBy(xpath = "//label[@class='checkbox-label' and @for='Metal']")
	WebElement metalBenches;
	public void clickMetalBenchFilter() {
		metalBenches.click();
	}
	
	@FindBy(xpath = "//span[text()='APPLY']")
	WebElement applyButton;
	public void clickApplyFilterButton() {
		applyButton.click();
	}
}
