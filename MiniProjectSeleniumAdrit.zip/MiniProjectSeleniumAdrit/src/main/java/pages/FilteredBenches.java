package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FilteredBenches {
	private JavascriptExecutor js;
	public FilteredBenches(WebDriver driver) {
		this.js = (JavascriptExecutor) driver;
		PageFactory.initElements(driver, this);
		driver.navigate().to("https://www.pepperfry.com/category/settees-and-benches.html?cat_id=2683&requestPlatform=web&sort_field=sorting_score&sort_by=desc&type=hover-furniture-setteesbenches&page=1&furniture_material_group=Metal");
	}
	
	@FindBy(xpath = "/html/body/app-root/main/app-category/pf-clip/div/div[2]/pf-clip-product-listing/div[1]/div/span[2]")
	WebElement countOfMetalBenches;
	public String scrollToCountAndDsiplay() {
        while (!countOfMetalBenches.isDisplayed()) {
            js.executeScript("window.scrollBy(0, 100);");
            try {
                Thread.sleep(500); // Adjust the sleep time as needed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return countOfMetalBenches.getText();
    }
	
}
