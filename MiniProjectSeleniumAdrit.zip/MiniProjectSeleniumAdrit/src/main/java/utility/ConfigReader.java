package utility;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigReader {
	static Properties prop;
	
	public static void readConfig() throws IOException{
		String filePath = "C:\\Users\\2408330\\eclipse-workspace\\MiniProjectSelenium\\src\\test\\resources\\config.properties";
		
		prop = new Properties();
		FileReader FR = new FileReader(filePath);
		prop.load(FR);
	}
	
	public static String getURL() {
		return prop.getProperty("url");
	}
}
