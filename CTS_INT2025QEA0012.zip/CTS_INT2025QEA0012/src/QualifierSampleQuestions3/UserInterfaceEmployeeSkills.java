package QualifierSampleQuestions3;
import java.util.*;

public class UserInterfaceEmployeeSkills {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("How many employees do you want to enter? ");
		int num = Integer.parseInt(sc.nextLine());
		
		EmployeeSkills es = new EmployeeSkills();
		System.out.println("Enter the details of " + num + " employees: ");
		for(int i  = 0; i < num; i++) {
			es.addToEmp(sc.nextLine());
		}
		
		System.out.println("What skill employee do you want? ");
		String skill = sc.nextLine();
		
		Set<String> result = es.filterSet(skill);
		
		if(result.isEmpty()) {
			System.out.println("No such employees found.");
			return;
		}
		
		System.out.println("Employees based on your skillset requirements are: ");
		for(String x : result) {
			System.out.println(x);
		}
	}
}
