package QualifierSampleQuestions3;

public class Partner {
	protected String partnerId, partnerName, contactNumber;
	protected double orderAmount;
	
	

	public Partner(String partnerId, String partnerName, String contactNumber, double orderAmount) {
		this.partnerId = partnerId;
		this.partnerName = partnerName;
		this.contactNumber = contactNumber;
		this.orderAmount = orderAmount;
	}
}
