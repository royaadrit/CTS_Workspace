package QualifierSampleQuestions3;
import java.util.*;

public class ClothingStore {
	//different garments, for each garmet diffrent size, stock qunatity vaires by size
	// create a class , creata a  method, it will addStockDetails()-> argument is String stockDetails separated by ProductName:quantity
	//NameFormat TShirt-M:50, save in hashset no duplicacy
	// cretat method, filterGarmet(minquan, maxqunat);
	
	Set<String> garmentDetails = new HashSet<>();
	
	public void setGarmentDetails(String stockDetails) {
		garmentDetails.add(stockDetails);
	}
	
	public Set<String> filterGarment(int min, int max){
		Set<String> resultSet = new HashSet<>();
		for(String s : garmentDetails) {
			String[] input = s.split(":");
			if(Integer.parseInt(input[1]) >= min && Integer.parseInt(input[1]) <= max){
				resultSet.add(input[0]);
			}
		}
		return resultSet;
	}
}
