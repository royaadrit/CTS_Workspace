package QualifierSampleQuestions3;
import java.util.*;

public class UserInterfaceCloths {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of clothes: ");
		int n = Integer.parseInt(sc.nextLine());
		
		System.out.println("Enter the clothe details: ");
		ClothingStore cs = new ClothingStore();
		for(int i  = 0; i < n; i++) {
			cs.setGarmentDetails(sc.nextLine());
		}
		
		Set<String> res = new HashSet<>();
		
		System.out.println("Enter min quantity: ");
		int min = Integer.parseInt(sc.nextLine());
		
		System.out.println("Enter the max qunatity: ");
		int max = Integer.parseInt(sc.nextLine());
		
		res = cs.filterGarment(min, max);
		
		System.out.println("Clothes as per requrements: ");
		for(String s : res) {
			System.out.println(s);
		}
		sc.close();
	}
}
