package QualifierSampleQuestions3;

public class DeliveryPartner extends Partner{
	private double distance, deliveryRatePerKm;



	public DeliveryPartner(String partnerId, String partnerName, String contactNumber, double orderAmount, double distance, double deliveryRatePerKm) {
		
		super(partnerId, partnerName, contactNumber, orderAmount);
		this.distance = distance;
		this.deliveryRatePerKm = deliveryRatePerKm;
		// TODO Auto-generated constructor stub
	}

	
	public double calculateDeliveryCharge() {
		if(orderAmount> 5000) {
			return 0;
		}else {
			if(distance > 10) {
				double deliverCharge = distance * deliveryRatePerKm;
				return deliverCharge += 100;
			}else {
				return distance * deliveryRatePerKm;
			}
		}
	}
}
