package QualifierSampleQuestions3;
import java.util.*;

public class StringLogic {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your string: ");
		String input = sc.nextLine();
		
		if(!input.matches("[a-zA-Z]+")) {
			 System.out.println(" is an Invalid string.");
			 return;
		}
		
		System.out.println("Enter the chracter you want to replace in the string: ");
		String serc = sc.nextLine();
		char ser = serc.charAt(0);
		
		int index = input.indexOf(ser);
		if(index == -1) {
			System.out.println("Char you want to replace doesn't exist: ");
			return;
		}
		
		System.out.println("What do you want to replace it with?");
		String repl = sc.nextLine();
		char rep = repl.charAt(0);
		
		//input.replaceFirst(serc, repl);
		System.out.println("New String: " + input.replaceFirst(serc, repl));
		/*System.out.println("Enter you string: ");
		StringBuilder in = new StringBuilder(sc.nextLine());
		
		System.out.println("What char do you want to replace: ");
		char ser = sc.nextLine().charAt(0);
		
		System.out.println("What do you want to replace " + ser + " with: ");
		char rep = sc.nextLine().charAt(0);
		
		for(int i = 0; i < in.length(); i++) {
			if(in.charAt(i) == ser) {
				in.setCharAt(i, rep);
				break;
			}
		}
		
		System.out.println("New string is: " + in.toString());*/
		
		
		
		//abcdea
		
		// char to search = b
		// what do you want  to replace b with? = q
		// output = aqcdea
		// can also do using charArray
		
		
	}
}
