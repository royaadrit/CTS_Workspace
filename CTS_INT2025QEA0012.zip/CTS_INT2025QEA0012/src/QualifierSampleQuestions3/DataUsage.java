package QualifierSampleQuestions3;
import java.util.*;

public class DataUsage {
	Set<String> dataUsage = new HashSet<>();
	
	public void addData(String details) {
		dataUsage.add(details);
	}
	
	public List<String> filterData(int usage){
		List<String> res = new ArrayList<>();
		
		for(String x : dataUsage) {
			String[] input = x.split(":");
			if(Integer.parseInt(input[1]) >= usage) {
				res.add(input[0]);
			}
		}
		return res;
	}
}
