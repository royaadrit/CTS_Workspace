package QualifierSampleQuestions3;

public class Restaurant extends Partner{
	private double discountPercentage, taxPercentage;

	public Restaurant(String partnerId, String partnerName, String contactNumber, double orderAmount, double discountPercentage, double taxPercentage) {
		super(partnerId, partnerName, contactNumber, orderAmount);
		this.discountPercentage = discountPercentage;
		this.taxPercentage = taxPercentage;
	}
	
	
	public double calculateOrderCost() {
		
		double tax = orderAmount * taxPercentage * 0.01;
		if(orderAmount < 0) {
			return -1;
		}else if(orderAmount > 1000) {
			orderAmount -= orderAmount * discountPercentage * 0.01;
			return orderAmount + tax;
		} else {
			return orderAmount + tax;
		}
	}
	
}
