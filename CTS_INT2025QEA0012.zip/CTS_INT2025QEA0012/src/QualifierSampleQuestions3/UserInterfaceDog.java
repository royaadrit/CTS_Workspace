package QualifierSampleQuestions3;
import java.util.*;

public class UserInterfaceDog {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of dogs: ");
		int n = Integer.parseInt(sc.nextLine());
		
		DogInfo di = new DogInfo();
		System.out.println("Enter the dog details: ");
		for(int i = 0; i < n; i++) {
			di.addDogDetails(sc.nextLine());
		}
		
		System.out.println("Enter the age you want: ");
		int age = Integer.parseInt(sc.nextLine());
		
		System.out.println("Enter the breed you want: ");
		String breed = sc.nextLine();
		
		System.out.println("Your elligible dogs are: " + di.findDogByAgeAndBreed(age, breed));
	}
}
