package QualifierSampleQuestions3;
import java.util.*;

public class DogInfo {
	Set<String> dogSet = new TreeSet<>();
	
	public void addDogDetails(String dogDetails) {
		dogSet.add(dogDetails);
	}
	
	public Set<String> findDogByAgeAndBreed(int age, String breed){
		Set<String> resultSet = new HashSet<>();
		
		for(String s : dogSet) {
			String[] input = s.split(":");
			if(Integer.parseInt(input[2]) < age && input[1].equalsIgnoreCase(breed)) {
				resultSet.add(input[0]);
			}
		}
		return resultSet;
	}
	
	/*method 1 addDogdetails(String as parameter, implement treeset for storing);
	save in a treeset
	constraints-> DogName:DogBreed:Age
	methoid 2
	findDogByAgeAndBreed(int age, String Breed) {
		if age < age and breed == breed
				return a normal set;*/
	
}
