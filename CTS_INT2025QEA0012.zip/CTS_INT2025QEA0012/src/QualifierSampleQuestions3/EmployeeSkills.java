package QualifierSampleQuestions3;
import java.util.*;

public class EmployeeSkills {
	Set<String> emp = new HashSet<>();
	
	public void addToEmp(String details) {
		emp.add(details);
	}
	
	public Set<String> filterSet(String skill){
		Set<String> res = new HashSet<>();
		for(String x : emp) {
			String[] input = x.split(":");
			if(input[1].equals(skill) || input[2].equals(skill) || input[3].equals(skill)) {
				res.add(input[0]);
			}
		}
		return res;
	}
}
