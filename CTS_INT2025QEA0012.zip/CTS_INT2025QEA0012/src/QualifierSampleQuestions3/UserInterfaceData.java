package QualifierSampleQuestions3;
import java.util.*;
public class UserInterfaceData {
	 public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of connections: ");
		int num = Integer.parseInt(sc.nextLine());
		
		System.out.println("Enter the details of " + num + " connections: ");
		DataUsage du = new DataUsage();
		for(int i = 0; i < num; i++) {
			du.addData(sc.nextLine());
		}
		
		System.out.println("Enter the filtering criteria: ");
		int usage = Integer.parseInt(sc.nextLine());
		
		System.out.println("The connections based on your criteria are: " + du.filterData(usage));
	}
}
