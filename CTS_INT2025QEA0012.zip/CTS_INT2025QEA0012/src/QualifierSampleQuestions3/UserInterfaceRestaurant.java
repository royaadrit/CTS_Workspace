package QualifierSampleQuestions3;
import java.util.*;

public class UserInterfaceRestaurant {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the partnerId: ");
		String partnerId = sc.nextLine();
		
		System.out.println("Enter the partner name: ");
		String partnerName = sc.nextLine();
		
		System.out.println("Enter the contact number: ");
		String contactNumber = sc.nextLine();
		
		System.out.println("Enter the order amount: ");
		double orderAmount = Double.parseDouble(sc.nextLine());
		
		if(orderAmount < 0) {
			System.out.println("Invalid order amount: ");
			return;
		}
		
		System.out.println("Enter the discount percentage: ");
		double discountPercentage = Double.parseDouble(sc.nextLine());
		
		System.out.println("Enter the tax percentage: ");
		double taxPercentage = Double.parseDouble(sc.nextLine());
		

		Restaurant r = new Restaurant(partnerId, partnerName, contactNumber, orderAmount, discountPercentage, taxPercentage);

		System.out.println("Enter the delivery distance: ");
		double distance = Double.parseDouble(sc.nextLine());
		
		System.out.println("Enter the delivery rate per km: ");
		double deliveryRatePerKm = Double.parseDouble(sc.nextLine());
		DeliveryPartner dp = new DeliveryPartner(partnerId, partnerName, contactNumber, orderAmount, distance, deliveryRatePerKm);
		
		
		
		System.out.println("The total bill amount is: " + r.calculateOrderCost());

		System.out.println("The delivery charge is: " + dp.calculateDeliveryCharge());
		System.out.println("The total bill after delivery charge is: " + (r.calculateOrderCost() + dp.calculateDeliveryCharge()));


	}
}
