package QualifierSampleQuestions;
import java.util.*;

public class TwoDimensionalArray {
	
	public static void initiliaseMatrix(int[][] matrix, int rows, int cols) {
		for(int i = 0; i < rows; i++) {
			Arrays.fill(matrix[i], 0);
		}
	}
	
	public static boolean bookTicket(int[][] matrix, int rows, int cols) {
		boolean booking = false;
		if(matrix[rows][cols] == 1) {
			System.out.println("Seat already booked");
			return false;
		}else {
			matrix[rows][cols] = 1;
			System.out.println("Seat booked successfully.");
			return true;
		}
	}
	
	public static void printMatrix(int[][] matrix, int rows, int cols) {
		for(int i = 0; i < rows; i++) {
			System.out.print("[ ");
			for(int j = 0; j < cols; j++) {
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println("]");
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		final int rows = 6;
		final int cols = 6;
		int[][] twoD = new int[rows][cols];
		initiliaseMatrix(twoD, rows, cols);
		int totalSeats = (rows * cols) - 1;
		
		System.out.println("Size of the cinema hall is " + (totalSeats + 1));
		
		System.out.println("Intial theatre seatmap: 0 indicates empty seats.");
		printMatrix(twoD, rows, cols);
		
		System.out.println("Enter the number of seats you want to book: ");
		int numberOfSeats = sc.nextInt();
		
		if(numberOfSeats > totalSeats) {
			System.out.println("Your requirements exceed out capacity. Sorry for the invonvinence.");
			return;
		}else {
			for(int i = 0; i < numberOfSeats; i++) {
				System.out.println("Enter the row and coloumn of seat " + (i + 1));
				int row = sc.nextInt();
				int col = sc.nextInt();
				bookTicket(twoD, row, col);
			}
		}
		
		System.out.println("Final capacity after your booking: ");
		printMatrix(twoD, rows, cols);
		
	}
}
