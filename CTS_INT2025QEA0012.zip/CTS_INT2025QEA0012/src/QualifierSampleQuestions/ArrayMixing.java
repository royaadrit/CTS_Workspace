package QualifierSampleQuestions;
import java.util.*;

public class ArrayMixing {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the size of both arrays");
		int size1 = sc.nextInt();
		//int size2 = sc.nextInt();
		
		List<Integer> array1 = new ArrayList<>();
		List<Integer> array2 = new ArrayList<>();
		
		System.out.println("Enter the 1st array: ");
		for(int i = 0; i < size1; i++) {
			array1.add(sc.nextInt());
		}
		
		System.out.println("Enter the 2nd array: ");
		for(int i = 0; i < size1; i++) {
			array2.add(sc.nextInt());
		}
		//[1,2,3,4] array1 
		//[2,3,4,5] array2
		//[1+2, ]
		
		List<Integer> sumArray = new ArrayList<>();
		for(int i  = 0; i < size1; i++) {
			sumArray.add(array1.get(i) + array2.get(i));
		}
		
		//Collections.sort(sumArray);
		System.out.println("The max element is: " + sumArray.get(size1 - 1) + " The min element is: " + sumArray.get(0));
		
		
	}
}
