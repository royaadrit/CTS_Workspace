package QualifierSampleQuestions;
import java.util.*;

public class UniversityClass {
	//String collegeName;
	//double collegeFees;
	Map<String, Double> collegeDetails = new HashMap<>();
	
	public void addCollegeDetails(String collegeName, double collegeFees) {
		collegeDetails.put(collegeName, collegeFees);
	}
	
	public List<String> collegeList(double budget){
		List<String> list = new ArrayList<>();
		for(String x : collegeDetails.keySet()) {
			if(collegeDetails.get(x) <= budget) {
				list.add(x);
			}
		}
		return list;
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//System.out.println("Enter the number of colleges:");
		
		System.out.println("Enter the details of the college in string format: ");
		String[] input = sc.nextLine().split(":");
		try {
			if(input[0].matches("[a-zA-Z]+")) {
				
			}
			else {
				throw new InvalidCollegeException("College name is invalid.");
			}	
		}
		catch (InvalidCollegeException e) {
			System.out.println(e.getMessage());
		}
		if(!input[0].matches("[a-zA-Z]+")) {
			return;
		}
		UniversityClass uc = new UniversityClass();
		
		uc.addCollegeDetails(input[0], Double.parseDouble(input[1]));
		
		System.out.println("Enter your budget: ");
		double budget = sc.nextDouble();
		
		System.out.println("The colleges in your budget are: " + uc.collegeList(budget));
		
	}
}
