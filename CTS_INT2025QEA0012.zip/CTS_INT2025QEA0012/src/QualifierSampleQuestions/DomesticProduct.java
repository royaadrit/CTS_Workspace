package QualifierSampleQuestions;

public class DomesticProduct extends Product{
	private int discount;

	public DomesticProduct(int productId, String productName, int numberOfProducts, double pricePerProducts, int discount) {
		super(productId, productName, numberOfProducts, pricePerProducts);
		this.discount = discount;
	}
	//private variable needs getter setter to access even in child class
	public double calculateDomesticProductPrice() {
		double bill = getPricePerProducts() * getNumberOfProducts();
		return bill - (bill * discount * 0.01);
	}
	
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}

}
