package QualifierSampleQuestions;

public class InvalidCollegeException extends Exception{
	public InvalidCollegeException(String message) {
		super(message);
	}
}
