package QualifierSampleQuestions;
import java.util.*;

public class UserInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the product Id:");
		int id = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter the product name:");
		String name = sc.nextLine();
		
		System.out.println("Enter the number of products:");
		int n = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter the price per product:");
		double price = sc.nextDouble();
		sc.nextLine();
		
		System.out.println("Enter the product type:");
		String type = sc.nextLine();
		
		if(type.equalsIgnoreCase("Domestic")) {
			System.out.println("Enter the discout percentage:");
			int dis = sc.nextInt();
			
			DomesticProduct dp = new DomesticProduct(id, name, n, price, dis);
			System.out.println(dp.calculateDomesticProductPrice());
		}else {
			System.out.println("Enter you tax percentage:");
			int tax = sc.nextInt();
			
			InternationalProduct ip = new InternationalProduct(id, name, n, price, tax);
			System.out.println(ip.calculateInternationalProductPrice());
		}
		
	}
}
