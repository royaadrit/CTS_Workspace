package QualifierSampleQuestions;
import java.util.*;

public class StringManipulation {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your string");
		String in = sc.nextLine();
		in.toLowerCase();
		
		int size = in.length();

		int sumLeft = 0;
		int sumRight = 0;
		
		if(size % 2 != 0) {
			for(int i = 0; i < size / 2; i++) {
				sumLeft += in.charAt(i) - 'a';
			}
			for(int i = (size / 2 + 1); i < size; i++) {
				sumRight += in.charAt(i) - 'a';
			}
		}else {
			for(int i = 0; i < size / 2; i++) {
				sumLeft += in.charAt(i) - 'a';
			}
			for(int i = (size / 2); i < size; i++) {
				sumRight += in.charAt(i) - 'a';
			}
		}
		
		if(sumLeft == sumRight) {
			System.out.println("Sum of both halves is equal");
		}else {
			System.out.println("Sum of both halves unequal");
			System.out.println("Left Half = " + sumLeft + " Right Half = " + sumRight);
		}
	}
}
