package QualifierSampleQuestions;
import java.util.*;

public class Messenger {
	
	List<String> messageStore = new ArrayList<>();
	
	public void addMessage(String message) {
		messageStore.add(message);
	}
	
	public void getMessageInReverse() {
		if(messageStore.size() != 0) {
			for(int i = messageStore.size() - 1; i >= 0 ; i--) {
				System.out.println("The messages in reverse order is: " + messageStore.get(i));
			}
		}else {
			System.out.println("You have no messages.");
		}
			
	}
	
	public void clearList() {
		messageStore.clear();
	}
	
	public List<String> getList(){
		return messageStore;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of your messages: ");
		int n = sc.nextInt();
		sc.nextLine();
		
		Messenger m = new Messenger();
		System.out.println("Enter your messages: ");
		for(int i = 0; i < n; i++) {
			m.addMessage(sc.nextLine());
		}
		
		System.out.println(m.messageStore);
		
		m.getMessageInReverse();
		System.out.println("Do you want to clear the list ?");
		String ans = sc.nextLine();
		if(ans.equalsIgnoreCase("Yes")) {
			m.clearList();
		}
		
		System.out.println(m.messageStore);
		
	}
}
