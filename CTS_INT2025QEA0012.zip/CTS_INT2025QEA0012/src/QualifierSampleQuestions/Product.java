package QualifierSampleQuestions;
import java.util.*;

/*
inheritance-> Main class productClass (Parent class) attrbitues -> pid, ptype, number of products, priceperproduct
domesticproduct child class of parent class attribuites-> discount, method double calclatedomesticprice(){amount = amount - (amount * disount)}
internarionalproduct childclass of parent class attributes-> additional taxes
, method double calculateInternationprice(){amount = amount + (amount * taxes)}

*/

public class Product {
	private int productId;
	private String productName;
	private int numberOfProducts;
	private double pricePerProducts;
	
	public Product(int productId, String productName, int numberOfProducts, double pricePerProducts) {
		this.setProductId(productId);
		this.setProductName(productName);
		this.setNumberOfProducts(numberOfProducts);
		this.setPricePerProducts(pricePerProducts);
	}

	public double getPricePerProducts() {
		return pricePerProducts;
	}

	public void setPricePerProducts(double pricePerProducts) {
		this.pricePerProducts = pricePerProducts;
	}

	public int getNumberOfProducts() {
		return numberOfProducts;
	}

	public void setNumberOfProducts(int numberOfProducts) {
		this.numberOfProducts = numberOfProducts;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
}
