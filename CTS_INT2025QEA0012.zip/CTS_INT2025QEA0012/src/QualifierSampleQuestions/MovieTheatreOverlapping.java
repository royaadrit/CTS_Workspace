package QualifierSampleQuestions;
import java.util.*;

public class MovieTheatreOverlapping {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of shows you want to screen: ");
		int rows = sc.nextInt();
		
		int[][] hall = new int[rows][2];
		
		System.out.println("Enter the show timings");
		for(int i = 0; i < rows; i++) {
			hall[i][0] = sc.nextInt();
			hall[i][1] = sc.nextInt();
		}
		
		int numberOfScreens = 0;
		for(int i = 1; i < rows; i ++) {
			if(hall[i - 1][1] - hall[i][0] < 0) {
				numberOfScreens = numberOfScreens;
			}else {
				numberOfScreens += 1;
			}
		}
		System.out.println("Number of screens needed for " + rows + " movies are: " + (numberOfScreens+1));
	}
}
