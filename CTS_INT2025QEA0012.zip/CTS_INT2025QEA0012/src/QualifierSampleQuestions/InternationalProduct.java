package QualifierSampleQuestions;

public class InternationalProduct extends Product{
	
	private double taxeRate;
	public InternationalProduct(int productId, String productName, int numberOfProducts, double pricePerProducts, double taxRate) {
		super(productId, productName, numberOfProducts, pricePerProducts);
		this.setTaxeRate(taxRate);
	}
	public double getTaxeRate() {
		return taxeRate;
	}
	public void setTaxeRate(double taxeRate) {
		this.taxeRate = taxeRate;
	}
	
	public double calculateInternationalProductPrice() {
		double bill = getPricePerProducts() * getNumberOfProducts();
		return bill + (bill * taxeRate * 0.01);
	}

}
