package MockPractice;
import java.util.*;

public class UserInterace {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		List<Integer> l = new ArrayList<>();
		
		
		System.out.println("Enter the employee Id: ");
		int empId = sc.nextInt();
		sc.nextLine();
			
		System.out.println("Enter the employee name: ");
		String name = sc.nextLine();
			
		System.out.println("Enter the rating: ");
		int rating = sc.nextInt();
			
		Employee emp = new Employee();
		emp.setEmpId(empId);
		emp.setEmpName(name);
		emp.setToList(rating);
		
		try {
			System.out.println("Your rating is: " + emp.evaluatePerformance(rating));
		}catch(LowPerformanceException e) {
			System.out.println(e.getMessage());
		}
			
			
			
	}
}
