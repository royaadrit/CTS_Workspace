package MockPractice;

public interface PerformanceEvaluator {
	public String evaluatePerformance(Integer rating) throws LowPerformanceException;
}
