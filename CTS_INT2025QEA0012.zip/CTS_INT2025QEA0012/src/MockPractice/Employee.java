package MockPractice;
import java.util.*;

public class Employee implements PerformanceEvaluator{
	private int empId;
	private String empName;
	List<Integer> ratings = new ArrayList<>();
	
	public Integer getFromList(int index) {
		return ratings.get(index);
	}
	
	public void setToList(Integer element) {
		ratings.add(element);
	}
	
	public int getEmpId() {
		return empId;
	}
	
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	public String getEmpName() {
		return empName;
	}
	
	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public String evaluatePerformance(Integer rating) throws LowPerformanceException {
		// TODO Auto-generated method stub
		if(rating > 4.5) {
			return "Outstanding";
		}else if(rating >= 3 && rating <= 4) {
			return "Good";
		}else if(rating < 3) {
			return "Underperforming";
		}else {
			throw new LowPerformanceException("Your ratings are too low");
		}
	}
	
	
}
