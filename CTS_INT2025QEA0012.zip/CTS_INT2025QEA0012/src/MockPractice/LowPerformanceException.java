package MockPractice;

public class LowPerformanceException extends Exception{
	public LowPerformanceException(String message) {
		super(message);
	}
}
