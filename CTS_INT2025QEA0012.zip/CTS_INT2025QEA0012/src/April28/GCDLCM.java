package April28;
//2408330 Aadrit Roy
import java.util.Scanner;

public class GCDLCM {
	public static int calculateGCD(int a, int b) {
		while(b != 0) {
			int temp = b;
			b = a % b;
			a = temp;
		}
		return a;
	}
	public static int calculateLCM(int a, int b) {
		int great = Math.max(a, b);
		int small = Math.min(a, b);
		
		for(int i = great; ; i += great) {
			if(i % small == 0) {
				return i;
			}
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers for GCD & LCM");
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		System.out.println("GCD is: " + calculateGCD(a, b));
		System.out.println("GCD is: " + calculateLCM(a, b));
	}
	
}
