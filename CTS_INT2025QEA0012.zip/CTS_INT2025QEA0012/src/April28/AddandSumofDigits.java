package April28;
//2408330 Aadrit Roy
import java.util.Scanner;

public class AddandSumofDigits {
	public static int Addition(int a, int b) {
		return a + b;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers to be added");
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		System.out.println("Sum = " + Addition(a, b));
		
		//Sum of digits
		System.out.println("Enter number: ");
		int num = sc.nextInt();
		int sum = 0;
				
		while(a > 0) {
			int tempo = num % 10;
			sum += tempo;
			num = num / 10;
		}
				
		System.out.println("Sum = " + sum);
	}
}
