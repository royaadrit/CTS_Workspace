package April28;

import java.util.Scanner;

public class SwapWithoutTemp {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers to be swapped");
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		a = a + b;
		b = a - b;
		a = a - b;
		
		System.out.println("Values after swapping are:");
		System.out.println("a = " + a);
		System.out.println("b = " + b);

	}
}
