package April28;

public class Constructors {
	private String sName;
	private int age;
	
	
	public Constructors(String sName, int age) {
		this.sName = sName;
		this.age = age;
	}
	
	public String getName() {
		return sName;
	}
	
	public void setName(String name) {
		this.sName = name;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int x) {
		this.age = x;
	}
	public static void main(String[] args) {
		This t = new This("Alfred", 44);
		System.out.println(t.getName());
		System.out.println(t.getAge());
		
	}
}
