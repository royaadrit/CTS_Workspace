package April28;

import java.util.Scanner;

public class LCM {
	public static int calculateLCM(int a, int b) {
		int great = Math.max(a, b);
		int small = Math.min(a, b);
		
		for(int i = great; ; i += great) {
			if(i % small == 0) {
				return i;
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers for LCM");
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		System.out.println("GCD is: " + calculateLCM(a, b));
	}
}
