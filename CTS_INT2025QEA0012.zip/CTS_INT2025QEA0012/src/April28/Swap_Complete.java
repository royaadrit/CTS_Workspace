package April28;
//2408330 Aadrit Roy
import java.util.Scanner;

public class Swap_Complete {
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter two numbers to be swapped");
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		int temp = 0;
		
		temp = a;
		a = b;
		b = temp;
		
		
		// without temp
		System.out.println("Values after swapping are:");
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		
		System.out.println("Enter two numbers to be swapped");
		int x = sc.nextInt();
		int y = sc.nextInt();
		
		x = x + b;
		y = x - y;
		x = x - y;
		
		System.out.println("Values after swapping are:");
		System.out.println("a = " + x);
		System.out.println("b = " + y);
		
	}
}
