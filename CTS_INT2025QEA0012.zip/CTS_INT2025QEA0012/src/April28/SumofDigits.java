package April28;
//2408330 Aadrit Roy
import java.util.Scanner;

public class SumofDigits {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number: ");
		int a = sc.nextInt();
		int sum = 0;
		
		while(a > 0) {
			int temp = a % 10;
			sum += temp;
			a = a / 10;
		}
		
		System.out.println("Sum = " + sum);
	}
}
