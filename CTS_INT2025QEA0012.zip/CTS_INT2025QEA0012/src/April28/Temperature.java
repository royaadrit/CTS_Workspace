package April28;
//2408330 Aadrit Roy
import java.util.Scanner;

public class Temperature {
	
	public static double getFtoC(double faren) {
		
		double output;
		output = (faren - 32) * 5/9;
		return output;
	}
	
	public static double getCtoF(double cel) {
		double output;
		output = (cel * 9/5) + 32;
		return output;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("1. Celsius to Farenheit");
		System.out.println("2. Farenheit to Celsius");
		System.out.println("Enter your choice");
		
		int choice = sc.nextInt();
		
		if(choice == 1) {
			System.out.println("Enter temperature in Celsius: ");
			double celsius = sc.nextDouble();
			System.out.println("The temperature in Farenheit is: " + getCtoF(celsius));
		}
		
		if(choice == 2) {
			System.out.println("Enter temperature in Farenheit: ");
			double farenheit = sc.nextDouble();
			System.out.println("The temperature in Celsius is: " + getFtoC(farenheit));
		}
		sc.close();
	}
}
