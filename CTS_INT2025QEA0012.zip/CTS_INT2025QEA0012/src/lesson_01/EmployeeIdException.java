package lesson_01;


public class EmployeeIdException extends Exception{
	public EmployeeIdException(String message) {
		super(message);
	}
}
