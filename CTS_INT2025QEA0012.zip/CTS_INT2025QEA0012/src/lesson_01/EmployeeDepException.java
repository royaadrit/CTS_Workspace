package lesson_01;

public class EmployeeDepException extends Exception{
	public EmployeeDepException(String message) {
		super(message);
	}
}
