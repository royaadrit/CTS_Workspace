package lesson_01;
import java.util.*;

public class EmployeeDetails {
	Map<Integer, Double> empDetails = new HashMap<>();
	
	public void setMap(HashMap<Integer, Double> empDetails) {
		this.empDetails = empDetails;
	}
	
	public void addEmployee(Integer a, Double b) {
		empDetails.put(a, b);
	}
	
	public List<Integer> checkSalary(){
		List<Integer> list = new ArrayList<>(); 
		
		for(Integer ele : empDetails.keySet()) {
			if(empDetails.get(ele) > 10000) {
				list.add(ele);
			}
		}
		Collections.sort(list);
		return list;
	}
}
