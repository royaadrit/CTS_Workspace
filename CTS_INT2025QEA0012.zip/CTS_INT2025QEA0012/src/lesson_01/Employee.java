package lesson_01;

public class Employee {
	private int empId;
	private String empType;
	private String empDep;
	
	public int getEmpId() {
		return empId;
	}
	
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	public void setEmpType(String empType) {
		this.empType = empType;
	}
	
	public String getEmpType() {
		return empType;
	}
	
	public void setEmpDep(String empDep) {
		this.empDep = empDep;
	}
	
	public String getEmpDep() {
		return empDep;
	}
	
	public boolean checkId() {
		String id = empId + "0";
		System.out.println(id);
		if(id.length() != 7) {
			return false;
		}
		return true;
	}
	
	public boolean checkEmpType() {
		if(empType.equals("Interns")) {
			return true;
		} else if(empType.equals("FullTime")) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean checkEmpDep() {
		if(empDep.equals("QA")) {
			return true;
		} else if(empDep.equals("DEV")) {
			return true;
		}else {
			return false;
		}
	}
}
