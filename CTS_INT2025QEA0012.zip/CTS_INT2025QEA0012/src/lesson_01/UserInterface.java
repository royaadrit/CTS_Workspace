package lesson_01;
import java.util.*;

public class UserInterface {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the details of employees");
	
		
		String[] input = sc.nextLine().split(":");
		Employee emp = new Employee();
		
		try {
			if(input[0].length() != 6) {
				throw new EmployeeIdException("Please enter a valid ID");
			}else {
				emp.setEmpId(Integer.parseInt(input[0]));
				System.out.println("Employee ID is valid and equal to: " + emp.getEmpId());
			}
		}catch (EmployeeIdException e) {
			System.out.println(e.getMessage());
		}
		
		emp.setEmpType(input[1]);
		emp.setEmpDep(input[2]);
		
		try {
			if(emp.checkEmpType()) {
				System.out.println("Employee type is valid and equal to: " + emp.getEmpType());
			}else {
				throw new EmployeeTypeException("Please enter valid employee type");
			}
		}catch (EmployeeTypeException e){
			System.out.println(e.getMessage());
		}
		
		try {
			if(emp.checkEmpDep()) {
				System.out.println("Employee department is valid and equal to: " + emp.getEmpDep());
			}else {
				throw new EmployeeDepException("Please enter valid employee details");
			}
		}catch(EmployeeDepException e) {
			System.out.println(e.getMessage());
		}
	}
}
	