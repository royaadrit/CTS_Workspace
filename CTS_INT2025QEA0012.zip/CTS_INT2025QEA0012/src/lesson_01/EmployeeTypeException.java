package lesson_01;

public class EmployeeTypeException extends Exception{
	public EmployeeTypeException(String message) {
		super(message);
	}
}
