package QualifierSampleQuestions2;
import java.util.*;

public class UserInterfaceDeviceInfo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of devices: ");
		int n = sc.nextInt();
		sc.nextLine();
		
		DeviceInfo di = new DeviceInfo();
		System.out.println("Enter the details of " + n + " devices");
		for(int i = 0; i < n; i++) {
			di.addToSet(sc.nextLine());
		}
		
		System.out.println("Enter the minimum price of your budget: ");
		double min = sc.nextInt();
		System.out.println("Enter the maximum price of your budget: ");
		double max = sc.nextInt();
		
		Set<String> result = di.filterDevice(min, max);
		System.out.println("The devies as per your needs are: ");
		for(String x : result) {
			System.out.println(x);
		}
		
		
	}
}
