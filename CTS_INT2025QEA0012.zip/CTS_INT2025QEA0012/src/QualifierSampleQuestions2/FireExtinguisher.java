package QualifierSampleQuestions2;
import java.util.*;

public class FireExtinguisher {
	List<String> storageList = new ArrayList<>();
	
	public void addExtinguisherDetails(String extinguisherDetails) {
		storageList.add(extinguisherDetails);
	}
	
	public List<String> getExtinguisherDetails(){
		return storageList;
	}
	
	public List<String> findExtinguisherProductsInRange(double minimumPrice, double maximumPrice){
		List<String> resultList = new ArrayList<>();
		for(String e : storageList) {
			String[] input = e.split(":");
			if(Double.parseDouble(input[2]) >= minimumPrice && Double.parseDouble(input[2]) <= maximumPrice) {
				resultList.add(input[0]);
			}
		}
		return resultList;
	}
}
