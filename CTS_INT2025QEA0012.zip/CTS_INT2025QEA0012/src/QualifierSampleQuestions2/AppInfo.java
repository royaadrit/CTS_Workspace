package QualifierSampleQuestions2;

public class AppInfo {
	private String appId, developer;
	private int sizeInMB;
	protected boolean isFree;
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getDeveloper() {
		return developer;
	}
	public void setDeveloper(String developer) {
		this.developer = developer;
	}
	public int getSizeInMB() {
		return sizeInMB;
	}
	public void setSizeInMB(int sizeInMB) {
		this.sizeInMB = sizeInMB;
	}
	
	public AppInfo() {
		
	}
	
	public AppInfo(String appId, String developer, int sizeInMB, boolean isFree) {
		this.appId = appId;
		this.developer = developer;
		this.sizeInMB = sizeInMB;
		this.isFree = isFree;
	}
	
	public AppInfo verifyAppDetails(String appDetails) throws InvalidAppInfoException {
		String[] input = appDetails.split(":");
		if((input[0].matches("APP[0-9]{3}")) && (input[1].matches("[a-zA-Z]+")) && (Integer.parseInt(input[2]) >= 10) && (Integer.parseInt(input[2]) <= 100) && (input[3].equalsIgnoreCase("True") || (input[3].equalsIgnoreCase("False")))){
			AppInfo ai = new AppInfo(input[0], input[1], Integer.parseInt(input[2]), Boolean.parseBoolean(input[3]));
			return ai;
		}else {
			throw new InvalidAppInfoException("Invalid details provided");
		}
	}
}	

