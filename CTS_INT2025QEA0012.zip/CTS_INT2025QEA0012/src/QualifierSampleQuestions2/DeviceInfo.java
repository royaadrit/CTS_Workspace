package QualifierSampleQuestions2;
import java.util.*;

public class DeviceInfo {
	Set<String> deviceSet = new HashSet<>();
	
	public void addToSet(String input) {
		deviceSet.add(input);
	}
	
	public Set<String> filterDevice(double minPrice, double maxPrice){
		Set<String> resultSet = new HashSet<>();
		
		for(String e : deviceSet) {
			String[] input = e.split(",");
			if(input[1].equalsIgnoreCase("Active")) {
				if(Double.parseDouble(input[2]) >= minPrice && Double.parseDouble(input[2]) <= maxPrice) {
					resultSet.add(input[0]);
				}
			}
		}
		return resultSet;
	}
}
