package QualifierSampleQuestions2;
import java.util.*;

public class EVChargingStation {
	private String stationName, providerName, city;
	private int totalChargingStations;
	
	public EVChargingStation(String stationName, String providerName, String city, int totalChargingStations) {
		this.stationName = stationName;
		this.providerName = providerName;
		this.city = city;
		this.totalChargingStations = totalChargingStations;
	}

	public String getStationName() {
		return stationName;
	}

	public void setStationName(String stationName) {
		this.stationName = stationName;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getTotalChargingStations() {
		return totalChargingStations;
	}

	public void setTotalChargingStations(int totalChargingStations) {
		this.totalChargingStations = totalChargingStations;
	}
	
	public double calculateChargingCost(String EVType, int count) {
		if(count < 0) {
			return -1;
		}else {
			if(EVType.equals("Small")) {
				return 150.0 * count;
			}else if(EVType.equals("Large")) {
				return 300.0 * count;
			}else {
				return -1;
			}
		}
	}
	
}
