package QualifierSampleQuestions2;

public class InvalidAppInfoException extends Exception{
	public InvalidAppInfoException(String message) {
		super(message);
	}
}
