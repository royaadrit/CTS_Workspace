package QualifierSampleQuestions2;
import java.util.*;

public class UserInterfaceEV {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the station name: ");
		String stationName = sc.nextLine();
		
		System.out.println("Enter the provider name: ");
		String providerName = sc.nextLine();
		
		System.out.println("Enter the city: ");
		String city = sc.nextLine();
		
		System.out.println("Enter the total charing stations: ");
		int totalChargingStations = sc.nextInt();
		sc.nextLine();
		
		EVChargingStation ev = new EVChargingStation(stationName, providerName, city, totalChargingStations);
		
		System.out.println("Enter the EV type and count: ");
		String EVType = sc.nextLine();
		int count = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Station Name: " + ev.getStationName());
		System.out.println("Provider Name: " + ev.getProviderName());
		System.out.println("City Name: " + ev.getCity());
		System.out.println("Total Charging Points: " + ev.getTotalChargingStations());
		System.out.println("Estimated Charging Cost: Rs " + ev.calculateChargingCost(EVType, count));
		
	}
}
