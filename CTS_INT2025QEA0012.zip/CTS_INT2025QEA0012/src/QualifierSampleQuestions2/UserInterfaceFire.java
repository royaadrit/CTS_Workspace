package QualifierSampleQuestions2;
import java.util.*;

public class UserInterfaceFire {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of details to be added: ");
		int n = sc.nextInt();
		sc.nextLine();
		
		FireExtinguisher fe = new FireExtinguisher();
		System.out.println("Enter " + n + " details: ");
		for(int i = 0; i < n; i++) {
			fe.addExtinguisherDetails(sc.nextLine());
		}
		
		System.out.println("Enter the minimum price: ");
		int min = sc.nextInt();
		System.out.println("Enter the maximum price: ");
		int max = sc.nextInt();
		sc.nextLine();
		
		List<String> result = new ArrayList<>();
		result = fe.findExtinguisherProductsInRange(min, max);
		
		System.out.println("Fire Extinguisher Inventory: ");
		for(String x : result) {
			System.out.println(x);
		}	
	}
}
