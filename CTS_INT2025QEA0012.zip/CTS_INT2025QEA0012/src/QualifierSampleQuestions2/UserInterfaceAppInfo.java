package QualifierSampleQuestions2;
import java.util.*;

public class UserInterfaceAppInfo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the details of the app");
		String input = sc.nextLine();
		
		AppInfo a = new AppInfo();
		try {
			AppInfo ai = a.verifyAppDetails(input);
			System.out.println("App Id: " + ai.getAppId());
			System.out.println("Developer Name: " + ai.getDeveloper());
			System.out.println("Size in MB: " + ai.getSizeInMB() + " MB");
			System.out.println("Is Free or not: " + ai.isFree);
		} catch (InvalidAppInfoException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
}