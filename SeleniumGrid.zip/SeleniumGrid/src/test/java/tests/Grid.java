package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Grid {
	WebDriver driver;
	  @Test
	  public void GoogleTitle() {

		  driver.get("https://www.saucedemo.com/");
		  String title = driver.getTitle();
		  System.out.println(title);

	  }
	  @BeforeTest
	  public void beforeTest() throws MalformedURLException {
		  DesiredCapabilities cap = new DesiredCapabilities();
		  cap.setCapability("browserName", "MicrosoftEdge");
		  driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);
	  }
	 
	  @AfterTest
	  public void afterTest() {
		  driver.close();
	  }
}
